# iiyama – Prohnuté monitory 31"–35" do 10 000 Kč
*Alza.cz · stav ke 20. 9. 2026 · řazeno dle ceny*

---

## 1. 34" iiyama G-MASTER GCB3484WQSU-B1 — **7 419 Kč**
[Alza](https://www.alza.cz/levne-prohnute-monitory/18855757.htm) · Objednací kód: WA840w3d5 · Hodnocení: ⭐ 4,7 (3×)

| Parametr | Hodnota |
|---|---|
| Úhlopříčka | 34" (86,4 cm) |
| Prohnutí | 1500R |
| Panel | VA |
| Rozlišení | 3440 × 1440 (UWQHD, 21:9) |
| Obnovovací frekvence | 180 Hz |
| Odezva | 0,4 ms (MPRT) |
| Sync | FreeSync Premium |
| HDR | HDR400 |
| Podsvícení | LED |
| Konektory | 2× HDMI, 1× DisplayPort, 4× USB-A (hub), sluchátka |
| Reproduktory | 2 × 5 W |
| VESA | 100 × 100 mm |
| **Stojan – výška** | **+150 mm** |
| Stojan – náklon | 23° nahoru / 5° dolů |
| Stojan – otočení (swivel) | ano |
| Pivot | ne |
| Barva | černá |

---

## 2. 34" iiyama G-MASTER GCB3482WQSU-B1 — **7 447 Kč** *(Bronze sleva)*
[Alza](https://www.alza.cz/levne-prohnute-monitory/18855757.htm) · Objednací kód: WA840w3d4 · Hodnocení: ⭐ 4,8 (4×)

| Parametr | Hodnota |
|---|---|
| Úhlopříčka | 34" (86,4 cm) |
| Prohnutí | 1500R |
| Panel | VA |
| Rozlišení | 3440 × 1440 (UWQHD, 21:9) |
| Obnovovací frekvence | 120 Hz |
| Odezva | 0,6 ms (MPRT) |
| Sync | FreeSync Premium |
| Konektory | 2× HDMI, 1× DisplayPort, USB hub, sluchátka |
| Reproduktory | 2 × 5 W |
| VESA | 100 × 100 mm |
| **Stojan – výška** | **+150 mm** |
| Stojan – náklon | 23° nahoru / 5° dolů |
| Stojan – otočení (swivel) | ano |
| Pivot | ne |
| Barva | černá |

> 💡 Levnější a jinak totožný model s GCB3484, lišící se pouze frekvencí (120 vs 180 Hz) a odezvou.

---

## 3. 34" iiyama ProLite XCB3494WQSU-B1 — **7 599 Kč**
[Alza](https://www.alza.cz/levne-prohnute-monitory/18855757.htm) · Objednací kód: WA840w3g · Hodnocení: ⭐ 5,0 (1×)

| Parametr | Hodnota |
|---|---|
| Úhlopříčka | 34" (86,4 cm) |
| Panel | VA, matný |
| Rozlišení | 3440 × 1440 (UWQHD, 21:9) |
| Obnovovací frekvence | 120 Hz |
| Odezva | 0,4 ms |
| Sync | Adaptive-Sync |
| Konektory | 2× HDMI, 1× DisplayPort, USB hub, sluchátka |
| Reproduktory | 2 × 5 W |
| VESA | 100 × 100 mm |
| **Stojan – výška** | **+150 mm** |
| Stojan – náklon | 23° nahoru / 5° dolů |
| Stojan – otočení (swivel) | ano |
| Pivot | **ano (90°)** |
| Barva | černá |

---

## 4. 32" iiyama G-MASTER GCB3280QSU-B2 — **7 658 Kč** *(Bronze sleva −7 %, původně 8 299 Kč)*
[Alza](https://www.alza.cz/levne-prohnute-monitory/18855757.htm) · Objednací kód: WA982a35 · Hodnocení: ⭐ 5,0 (2×)

| Parametr | Hodnota |
|---|---|
| Úhlopříčka | 32" (81,3 cm) |
| Panel | VA, matný, 8 bit |
| Rozlišení | 2560 × 1440 (QHD, **16:9**) |
| Obnovovací frekvence | 180 Hz |
| Odezva | 0,2 ms (MPRT) |
| Sync | Adaptive-Sync |
| Konektory | 2× HDMI, 1× DisplayPort, USB hub, sluchátka |
| Reproduktory | 2 × 5 W |
| VESA | 100 × 100 mm |
| **Stojan – výška** | **+150 mm** |
| Stojan – náklon | 23° nahoru / 5° dolů |
| Stojan – otočení (swivel) | ano |
| Pivot | **ano (90°)** |
| Barva | černá |

> ⚠️ Jediný model s poměrem stran 16:9 (ostatní jsou 21:9 ultrawide). Nejnižší odezva ze všech.

---

## 5. 34" iiyama G-MASTER GCB3486WQSCP-B1 — **9 493 Kč** *(Bronze sleva −1 %; s kódem ALZADNY20: 7 594 Kč)*
[Alza](https://www.alza.cz/levne-prohnute-monitory/18855757.htm) · Objednací kód: WA840w3d6 · Hodnocení: ⭐ 4,3 (12×)

| Parametr | Hodnota |
|---|---|
| Úhlopříčka | 34" (86,4 cm) |
| Prohnutí | 1500R |
| Panel | VA |
| Rozlišení | 3440 × 1440 (UWQHD, 21:9) |
| Obnovovací frekvence | **240 Hz** |
| Odezva | 0,4 ms |
| Sync | FreeSync Premium |
| Konektory | 2× HDMI, 1× DisplayPort, **1× USB-C**, USB hub, **RJ-45 (LAN)**, sluchátka |
| Power Delivery | **95 W** (USB-C) |
| Reproduktory | 2 × 5 W |
| VESA | 100 × 100 mm |
| **Stojan – výška** | **+130 mm** |
| Stojan – náklon | 18,5° nahoru / 3,5° dolů |
| Stojan – otočení (swivel) | **ne** |
| Pivot | ne |
| Barva | černá |

> ⚠️ Nejnižší rozsah nastavení výšky (130 mm vs 150 mm), bez otočení. Jako jediný nabízí 240 Hz a USB-C Power Delivery 95 W + LAN.

---

## 6. 34" iiyama ProLite XCB3497WQSNP-B1 — **9 014 Kč** *(Bronze sleva −3 %, původně 9 319 Kč)*
[Alza](https://www.alza.cz/levne-prohnute-monitory/18855757.htm) · Objednací kód: WA840w3f · Hodnocení: ⭐ 3,5 (2×)

| Parametr | Hodnota |
|---|---|
| Úhlopříčka | 34" (86,4 cm) |
| Panel | VA, matný |
| Rozlišení | 3440 × 1440 (UWQHD, 21:9) |
| Obnovovací frekvence | 120 Hz |
| Odezva | 0,4 ms |
| Sync | Adaptive-Sync |
| Konektory | 2× HDMI, 1× DisplayPort, **1× USB-C**, USB hub, **RJ-45 (LAN)**, sluchátka |
| Reproduktory | 2 × 5 W |
| VESA | 100 × 100 mm |
| **Stojan – výška** | **+150 mm** |
| Stojan – náklon | 23° nahoru / 5° dolů |
| Stojan – otočení (swivel) | ano |
| Pivot | **ano (90°)** |
| Barva | černá |

---

## 7. 34" iiyama ProLite XCB3497WQSNPH-B1 — **9 491 Kč** *(Bronze sleva −1 %, původně 9 589 Kč)*
[Alza](https://www.alza.cz/levne-prohnute-monitory/18855757.htm) · Objednací kód: WA840w3d3

| Parametr | Hodnota |
|---|---|
| Úhlopříčka | 34" (86,4 cm) |
| Panel | VA, matný |
| Rozlišení | 3440 × 1440 (UWQHD, 21:9) |
| Obnovovací frekvence | 120 Hz |
| Odezva | 0,4 ms |
| Sync | Adaptive-Sync |
| Konektory | 2× HDMI, 1× DisplayPort, **1× USB-C**, USB hub, **RJ-45 (LAN)**, sluchátka |
| Power Delivery | **95 W** (USB-C) |
| Webkamera | **ano** (Windows Hello) |
| Reproduktory | 2 × 5 W |
| VESA | 100 × 100 mm |
| **Stojan – výška** | **+150 mm** |
| Stojan – náklon | 23° nahoru / 5° dolů |
| Stojan – otočení (swivel) | ano |
| Pivot | ne |
| Barva | černá |

---

## Srovnávací přehled – stojan a polohovatelnost

| Model | Cena | Výška stojanu | Náklon | Swivel | Pivot |
|---|---|---|---|---|---|
| GCB3484WQSU-B1 | 7 419 Kč | **150 mm** | 23° / 5° | ✅ | ❌ |
| GCB3482WQSU-B1 | 7 447 Kč | **150 mm** | 23° / 5° | ✅ | ❌ |
| XCB3494WQSU-B1 | 7 599 Kč | **150 mm** | 23° / 5° | ✅ | ✅ |
| GCB3280QSU-B2 | 7 658 Kč | **150 mm** | 23° / 5° | ✅ | ✅ |
| GCB3486WQSCP-B1 | 9 493 Kč | 130 mm | 18,5° / 3,5° | ❌ | ❌ |
| XCB3497WQSNP-B1 | 9 014 Kč | **150 mm** | 23° / 5° | ✅ | ✅ |
| XCB3497WQSNPH-B1 | 9 491 Kč | **150 mm** | 23° / 5° | ✅ | ❌ |

---

*Specifikace stojanu ověřeny na iiyama.com. Ceny jsou aktuální k datu sběru a mohou se měnit.*
